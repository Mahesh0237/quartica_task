import React from 'react'

function TaskDetails() {
  return (
    <div>TaskDetails</div>
  )
}

export default TaskDetails
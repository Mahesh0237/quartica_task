import React from 'react'
import Approuter from './Approuter'

function App() {
  return (
    <Approuter/>
  )
}

export default App
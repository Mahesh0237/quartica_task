import React from 'react'
import Tasklistwrapper from '../components/tasklist/Tasklistwrapper'

function Tasklistpage() {
  return (
    <Tasklistwrapper/>
  )
}

export default Tasklistpage